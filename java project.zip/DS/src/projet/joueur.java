package projet;

class joueur {

	private int ss,st;

public joueur(int ss,int st) {
this.setSs(ss);this.setSt(st);}

public int getSs() {return ss;}
public void setSs(int ss) {this.ss = ss;}

public int getSt() {return st;}
public void setSt(int st) {this.st = st;}}
