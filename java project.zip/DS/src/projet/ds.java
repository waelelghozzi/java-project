package projet;

import java.io.Serializable;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import java.util.LinkedList;
import java.util.Scanner;







public class ds {

	public static void main(String[] args) throws empty, IOException, ClassNotFoundException {
		Scanner x =new Scanner(System.in); 

		
		LinkedList <Ques> L=new LinkedList<>();
		
		
		
		int vr,v3;
		do {
			System.out.print("Connecter tent que un joueur ou un editeur ? 0/1 \n");
			int v=x.nextInt();
			if (v==1) {
				System.out.print("inisialiser les questions/ ajouter un question/ supprimer un question/ modifier un question excistant ? 0/1/2/3");
				int v2=x.nextInt();
				
				if(v2==0) {
					System.out.print("inisialisation automatique des questions ? 0/1 ");
					 v3=x.nextInt();
					if(v3==1) {
						L.clear();
						Ques Q = new Ques("O� se trouvent les glandes sudoripares d'un chien"," sur ses pattes"," Sous ses pattes",
								" Sous ses deriere pattes seulement"," Sous ses avant pattes seulement"," Sous ses pattes",800,0);
						L.add(Q);
						Q = new Ques("Qui fut le quaranti�me pr�sident des USA ?","Reagan","Clinton","Trump","Il beji","Reagan",1500,1);
						L.add(Q);
						 Q = new Ques("Que signifie Bistro en russe ?","vite","sort","mange","mal","vite",3000,0);
							L.add(Q);
						 Q = new Ques("Combien y a-t-il de miles marins dans un degr� de latitude ?","150","60","55","5","60",6000,0);
							L.add(Q);
						 Q = new Ques("Qui est le dieu du Soleil dans l'ancienne Egypte ?","R�","amoun","khoufou","hakun","R�",12000,0);
							L.add(Q);
						 Q = new Ques("Quelle est la capitale des Bermudes ?","sirilanka","Hamilton","tokyo","madrid","Hamilton",24000,0);
							L.add(Q);
						 Q = new Ques("Quel a �t� le premier nom du jeu de boules ?","Le Boulingrins","bouzemzem","Le Bouling","Le Boulies","Le Boulingrins",48000,1);
							L.add(Q);
						 Q = new Ques("Quel est le nom officiel du terrain de tennis ?","Le court","Le terrain","Le terratoire","Le couloire","Le court",72000,0);
							L.add(Q);
						 Q = new Ques("Quelle ville a construit le premier m�tro ?","Londres","madrid","paris","tokyo","Londres",100000,0);
							L.add(Q);
						 Q = new Ques("Combien y a-t-il de joueurs sur le terrain dans une �quipe de base-ball ?","11","9","120","69","9",150000,0);
							L.add(Q);
						 Q = new Ques(" Qui est Le Magnifque ?","Jean-Paul Belmondo","jhon pierre","kujoo jotaro","roronowa zoro","Jean-Paul Belmondo",300000,0);
							L.add(Q);
						 Q = new Ques("Compl�tez ce c�l�bre slogan... Coca-cola","Never","Always","jour et nuit","Just do it","Always",1000000,0);
							L.add(Q);
							
				
							
						//adding to file here
							
						try {FileOutputStream fos = new FileOutputStream("L.ser");
								ObjectOutputStream oos = new ObjectOutputStream (fos);
								oos.writeObject(L);
								oos.close();}catch(IOException e) {
							System.out.println(e.getMessage());}
								
								
								System.out.println("inisialisation auto avec succes !");
								
								
							
							}
					else {
						L.clear();int s=800;
					for(int i=0;i<12;i++) {
						int p=0;
						if((i==1)||(i==6)) {
							p=1;
						}
				
						x.nextLine();
					System.out.println("donner le question num "+ i);
					String q=x.nextLine();
					
					System.out.println("donner la 1ere reponce");
					String r1=x.nextLine();
					
					System.out.println("donner la 2eme reponce");
					String r2=x.nextLine();
					
					System.out.println("donner la 3eme reponce");
					String r3=x.nextLine();
					
					System.out.println("donner la 4eme reponce");
					String r4=x.nextLine();
					
					System.out.println("donner la reponce correcte");
					String rc=x.nextLine();
					
					if(i==0) {s=(s*2)+100;}
				      else {s=s*2;}
					try {Ques Q = new Ques(q,r1,r2,r3,r4,rc,s,p);L.add(i,Q);}
					catch(empty e) {
						System.out.println(e.get_msg());
						
					}}
					//adding to file here
					try {FileOutputStream fos = new FileOutputStream("L.ser");
					ObjectOutputStream oos = new ObjectOutputStream (fos);
					oos.writeObject(L);
					oos.close();}catch(IOException e) {
				System.out.println(e.getMessage());}}}
				
			
			
				else if(v2==1) {
					
					try {
						
							FileInputStream fis = new FileInputStream("L.ser");
							
					try (ObjectInputStream ois = new ObjectInputStream (fis)) {
						L = (LinkedList)ois.readObject();
						
						
					}catch(ClassNotFoundException e){
						System.out.println(e.getMessage());}
					}catch(IOException e) {
						System.out.println(e.getMessage());}
				
					
					if(L.size()==12) {
						System.out.println("les questions en max");}
					
					else {
						System.out.println("donner lindice du question a ajouter");
						int i,s,p2;
						do { i =x.nextInt();}while((i<1)||(i>12));
						 p2=0;
						 
						if((i==2)||(i==7)) {p2=1;}
						x.nextLine();
						System.out.println("donner le question num "+ i);
						String q=x.nextLine();
						
						System.out.println("donner la 1ere reponce");
						String r1=x.nextLine();
						
						System.out.println("donner la 2eme reponce");
						String r2=x.nextLine();
						
						System.out.println("donner la 3eme reponce");
						String r3=x.nextLine();
						
						System.out.println("donner la 4eme reponce");
						String r4=x.nextLine();
						
						System.out.println("donner la reponce correcte");
						String rc=x.nextLine();
						
						int k=i-1;
						if(k==0) {s=800;}
						else if(k==1) {s=1500;}
						else {s=1500; for(int j=1;j<=k;j++){s=s*2;}}
						try {Ques Q = new Ques(q,r1,r2,r3,r4,rc,s,p2);L.add(i-1,Q);}
						catch(empty e) {
							System.out.println(e.get_msg());
						}}
					//overwrite to file here
					try {FileOutputStream fos = new FileOutputStream("L.ser");
					ObjectOutputStream oos = new ObjectOutputStream (fos);
					oos.writeObject(L);
					oos.close();}catch(IOException e) {
				System.out.println(e.getMessage());}
				}
				
		else if(v2==2) {
			FileInputStream fis = new FileInputStream("L.ser");
			ObjectInputStream ois = new ObjectInputStream (fis);
			L = (LinkedList)ois.readObject();
			
			if(L.size()==0) {System.out.println("pas des questions dans la liste..");}
			else {
				System.out.println("donner lindice du question a supprimer");
				int i;
				do { i =x.nextInt();}while((i<1)||(i>12));
				L.remove(i-1);
				System.out.println("le question etait supprimer");}}
				
			else {
				System.out.println("donner lindice du question a modifier");
				int i,s,p2;
				do { i =x.nextInt();}while((i<1)||(i>12));
				 p2=0;
				 
				if((i==2)||(i==7)) {p2=1;}
				x.nextLine();
				System.out.println("donner le nouveau question num "+ i);
				String q=x.nextLine();
				
				System.out.println("donner la 1ere reponce");
				String r1=x.nextLine();
				
				System.out.println("donner la 2eme reponce");
				String r2=x.nextLine();
				
				System.out.println("donner la 3eme reponce");
				String r3=x.nextLine();
				
				System.out.println("donner la 4eme reponce");
				String r4=x.nextLine();
				
				System.out.println("donner la reponce correcte");
				String rc=x.nextLine();
				
				int k=i-1;
				if(k==0) {s=800;}
				else if(k==1) {s=1500;}
				else {s=1500; for(int j=1;i<=k;i++){s=s*2;}}
				
				try {Ques Q = new Ques(q,r1,r2,r3,r4,rc,s,p2);L.set(i-1,Q);}
				catch(empty e) {
					System.out.println(e.get_msg());
				}
				
				
			}
				//overwrite to file here
				FileOutputStream fos = new FileOutputStream("L.ser");
				ObjectOutputStream oos = new ObjectOutputStream (fos);
				oos.writeObject(L);
				oos.close();
				}
			
			
			else {
				
				
				FileInputStream fis = new FileInputStream("L.ser");
				ObjectInputStream ois = new ObjectInputStream (fis);
				L = (LinkedList)ois.readObject();
				
				if(L.size()!=12) {System.out.println("il ya pas des questions suffisant pour jouer ! \n");}
				else {
				boolean t=false;int i2;
				joueur j =new joueur(0,0);
				for(int i=0;i<L.size();i++) {
					i2=i+1;
					System.out.println("le question num "+i2+" est le suivant\n");
					System.out.println(L.get(i).getq());
					System.out.println("les reponses possibles sont les suivants\n");
					System.out.println("1 : "+L.get(i).getR1());
					System.out.println("2 : "+L.get(i).getR2());
					System.out.println("3 : "+L.get(i).getR3());
					System.out.println("4 : "+L.get(i).getR4()+"\n");
					System.out.println("taper le numero de votre reponse");
					int r=x.nextInt();
					
					if(r==1) {if(L.get(i).getR1().equals(L.get(i).getRc())){t=true;}else{t=false;}}
					else if(r==2) {if(L.get(i).getR2().equals(L.get(i).getRc())){t=true;}else{t=false;}}
					else if(r==3) {if(L.get(i).getR3().equals(L.get(i).getRc())){t=true;}else{t=false;}}
					else {if(L.get(i).getR4().equals(L.get(i).getRc())){t=true;}else{t=false;}}
					
					if(t==true) {	System.out.println("la reponse est correct !\n");
						if((i==1)||(i==6)) {j.setSs(L.get(i).getScore());}
						j.setSt(L.get(i).getScore());}
					else {	System.out.println("la reponse n'est pas correct !\n");
						break;}}
				if(t==false) {System.out.println("tu as perdu le jeu, mais votre score est :"+j.getSs());}
				else {System.out.println("tu as gagner le "+j.getSt()+" !!");}
				}}
			
			
			
			
			
			
			System.out.println("relancer ? 0/1");
			vr=x.nextInt();
			
		}while(vr==1);
		
		
		
	      
	
 x.close();
	}

}
